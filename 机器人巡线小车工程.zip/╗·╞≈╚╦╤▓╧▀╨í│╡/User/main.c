#include "stm32f10x.h"                  // Device header
#include "Delay.h"
#include "OLED.h"
#include "timer3.h"
#include "Key.h"
#include "motor.h"
#include "Encode.h"
#include "PID.h"
int16_t key,target_speed,actual_speed,motor_input;
uint8_t time;
PID mypid;
int main(void)
{
	
	TIM4_Iint();
	Motor_Init();
	Encode_Iint();
	OLED_Init();
	key_Init();
	OLED_ShowString(1,1,"targetSpeed:");
    OLED_ShowString(2,1,"actualSped:");
	PID_Init(&mypid,2,0,1,1,100);
	while(1)
	{
		 key=key_GetNum();
		 if(key==1)
		 {
			 target_speed+=15;
			 if(target_speed>75)
			 {
				 target_speed=0;
			 }
		 }
		
		 if(motor_input>400)
		 {
			 motor_input=400;
		 }
		 if(motor_input<-400)
		 {
			 motor_input=-400;
		 }
		  if(target_speed==0)
		 {
			 motor_input=0;
		 }
		 Mortor_Speed(motor_input);//500Ϊ��ռ�ձ�
		 OLED_ShowNum(1,13,target_speed,3);
		 OLED_ShowSignedNum(2,12,actual_speed,4);
		 OLED_ShowSignedNum(3,12,motor_input,4);
		 
		 OLED_ShowSignedNum(4,12,PID_control(&mypid,target_speed,actual_speed),4);
	}
	
}
void TIM4_IRQHandler(void)
{
	if(TIM_GetITStatus(TIM4,TIM_IT_Update)==SET)
	{
		actual_speed=Encoder_get();
		TIM_ClearITPendingBit(TIM4,TIM_IT_Update);
		time++;
		if(time>6)
		{
			motor_input+=PID_control(&mypid,target_speed,actual_speed);
			time=0;
		}
	}
}
