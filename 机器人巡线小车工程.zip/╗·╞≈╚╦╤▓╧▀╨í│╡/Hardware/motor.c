#include "stm32f10x.h"                  // Device header
#include "PWM.h"
void Motor_Init()
{
	PWM_Init();
	
}   
void Mortor_Speed(int16_t compare)
{
	PWM_SetCompare3(compare);
}
