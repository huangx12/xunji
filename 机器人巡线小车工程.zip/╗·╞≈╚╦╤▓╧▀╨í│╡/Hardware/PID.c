#include "stm32f10x.h"                  // Device header
#include "PID.h" 
extern PID mypid;

void PID_Init(PID *pid,int p,int i,int d,int maxI,int maxOut)
{
    pid->kp=p;
    pid->ki=i;
    pid->kd=d;
    pid->maxIntegral=maxI;
    pid->maxOutput=maxOut;
}

int PID_control(PID *pid,int target_speed,int actual_speed)
{
	int result;
	pid->lastError=pid->error;
	pid->error=target_speed-actual_speed;
	pid->integral+=pid->error;
	result=pid->kp*pid->error+pid->ki*pid->integral+(pid->error-pid->lastError)*pid->kd;
	if(result>pid->maxOutput)
	{
		result=pid->maxOutput;
	}
	return result;
}
