#ifndef __key_H__
#define __key_H__
 void key_Init(void);
 uint8_t key_GetNum(void);

#endif
