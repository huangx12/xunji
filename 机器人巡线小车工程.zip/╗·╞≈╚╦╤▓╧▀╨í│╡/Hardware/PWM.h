#ifndef __PWM_H__
#define __PWM_H__
 void PWM_Init(void);
 void PWM_SetCompare3(uint16_t compare);
#endif
