#ifndef __PID_H__
#define __PID_H__
typedef struct
{
   	int kp,ki,kd;
    int error,lastError;
    int integral,maxIntegral;
    int output,maxOutput;
}PID;
int PID_control(PID *pid,int target_speed,int actual_speed);
void PID_Init(PID *pid,int p,int i,int d,int maxI,int maxOut);
#endif