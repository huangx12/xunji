#ifndef __ENCODE_H__
#define __ENCODE_H__
 int16_t Encoder_get(void);
 void Encode_Iint(void);
#endif
