#ifndef __MOTOR_H__
#define __MOTOR_H__
void Motor_Init(void);
void Mortor_Speed(int16_t compare);
#endif
