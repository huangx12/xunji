#include "stm32f10x.h"                  // Device header
void PWM_Init()
{
	RCC_APB1PeriphClockCmd(RCC_APB1Periph_TIM2,ENABLE);//开启TIM2的时钟
	
	RCC_APB2PeriphClockCmd(RCC_APB2Periph_GPIOA,ENABLE);
	GPIO_InitTypeDef GPIO_InitStructure;
	GPIO_InitStructure.GPIO_Mode=GPIO_Mode_AF_PP;
	GPIO_InitStructure.GPIO_Pin=GPIO_Pin_2;
	GPIO_InitStructure.GPIO_Speed=GPIO_Speed_50MHz;
	GPIO_Init(GPIOA,&GPIO_InitStructure);
	
	TIM_InternalClockConfig(TIM2);//选择内部时钟晶振
	TIM_TimeBaseInitTypeDef TIM_TimeBaseInitStructure;//时基单元
	TIM_TimeBaseInitStructure.TIM_ClockDivision=TIM_CKD_DIV1;
	TIM_TimeBaseInitStructure.TIM_CounterMode=TIM_CounterMode_Up;
	TIM_TimeBaseInitStructure.TIM_Period=500-1;//ARR，500为满占空比
	TIM_TimeBaseInitStructure.TIM_Prescaler=800-1;//PSC
	TIM_TimeBaseInitStructure.TIM_RepetitionCounter=0;
	TIM_TimeBaseInit(TIM2,&TIM_TimeBaseInitStructure);
	
	TIM_OCInitTypeDef TIM_OCInitTStructure;
	TIM_OCStructInit(&TIM_OCInitTStructure);//把结构体赋初值
	
	TIM_OCInitTStructure.TIM_OCMode=TIM_OCMode_PWM1;//输出比较模式
	TIM_OCInitTStructure.TIM_OCPolarity=TIM_OCPolarity_High;//输出极性
	TIM_OCInitTStructure.TIM_OutputState=TIM_OutputState_Enable;
	TIM_OCInitTStructure.TIM_Pulse=0;//CCR的值
	TIM_OC3Init(TIM2,&TIM_OCInitTStructure);
	 
	TIM_Cmd(TIM2,ENABLE);
}

void PWM_SetCompare3(uint16_t compare)
{
	TIM_SetCompare3(TIM2,compare);
}